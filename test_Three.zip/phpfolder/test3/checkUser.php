<?php
 include("conn.php");
header('Access-Control-Allow-Orign: * ');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
?>

	<div class="container">
	<div class="row">
		<?php
			if($_POST["submitL"]){
				$email = $_POST["email"];
				$password = $_POST["password"];
								
				$query = "SELECT * FROM `users` WHERE `email` = '$email' AND `password` = '$password'";
				$result = mysqli_query($conn,$query);
				$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
				  
				$count = mysqli_num_rows($result);
				if($count == 1) {
					echo "<script>
							alert('Registration Successful! Login to continue.');
							window.location.href='http://10.51.219.142:3000/sendMail.html';
						</script>";
						header("location: http://10.51.219.142:3000/sendMail.html");
					echo "Welcome ".$row["name"];
					$_SESSION['email'] = $row["email"];
				}else {
					echo "Your Login Name or Password is invalid";
				}
				
			}
		?>
	</div>
</div>