<?php
 include("conn.php");
header('Access-Control-Allow-Orign: * ');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');

$email = $_POST["toEmail"];
$sub = $_POST["subject"];
$message = $_POST["message"];
$fromEmail = $_POST["fromEmail"];
	$query = "INSERT INTO `emais` (`toEmail`,`subject`,`message`,`fromEmail`) VALUES ('$email','$sub','$message',$fromEmail)";
					mysqli_query($conn,$query);
	header("location: http://10.51.219.142:3000/sendMail.html");
?>