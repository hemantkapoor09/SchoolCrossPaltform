<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no, width=device-width">
            </head>
            <body>
            <!-- <script type="text/javascript" src="cordova.js"></script> -->
            	

<?php 
	header('Access-Control-Allow-Orign: *');
	header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
	include("conn.php");
?>
<div class="container">
	<div class="row">
		<?php
			if($_POST["submitR"]){
				$name = $_POST["name"];
				$email = $_POST["email"];
				$password = $_POST["password"];
				$confirm_password = $_POST["confirm-password"];
				
				if($password == $confirm_password){
					$query = "INSERT INTO `users` (`email`,`password`,`name`) VALUES ('$email','$confirm_password','$name')";
					mysqli_query($conn,$query);
					echo "<script>
							alert('Registration Successful! Login to continue.');
						</script>";
				header("location: http://10.51.219.142:3000/");
				}else{
					echo "<script>
							alert('Both Passwords must be same!');
							</script>";
				}
			}
		?>
	</div>
</div>
            </body>
            </html>
