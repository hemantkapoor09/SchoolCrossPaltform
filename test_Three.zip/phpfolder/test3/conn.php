<?php
header('Access-Control-Allow-Orign: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
	$servername = "localhost";
	$username = "root";
	$password = "";
	$db = "phoneMail";

	$conn = new mysqli($servername, $username, $password, $db);

	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}


?>