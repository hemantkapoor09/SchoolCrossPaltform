<?php 
	include("conn.php");
	    $docId= $_POST['doctorId'];
    					?>
    					<form class='form_text' action='bookAppByUser.php'  method='POST'>
    					<?php
         				for($i=0;$i<7;$i++)
    					{
    						$d=strtotime("+".$i." day"); 
    						$dayT = date("l",$d);
    						$dateT = date("Y/m/d",$d);



								    $query = "SELECT `date`, `docId` FROM `appointment` WHERE `date` = '$dateT' AND `docId` = '$docId' ";
									$result = mysqli_query($conn,$query);
									$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
									$count = mysqli_num_rows($result);
									if($row['date'] == $dateT)
									{
										$str ="";
									}				
									else{
										$str = "disabled";
									}
    						echo ("
				    				 <tr>
				    					<td id='docDate'>
    										<input type='radio' name='avilable' id='dateAvl' value='".$dateT."' ".$str." >&nbsp;&nbsp;".
		    								$dayT."&nbsp;&nbsp;". $dateT."
				    					</td>
				    				</tr><br>"
		    					);
    					} 	
    					echo("<input type='text' name='docId' hidden='true' value='".$docId."'/>");
           ?>
          <button type="submit" class="btn btn-info">Book Now</button>

 		</form>