<?php 
	include("conn.php");
    $uId=$_SESSION['userId'];
    $docId = $_POST['docId'];
    $bookdate=$_POST['avilable'];
    

				$query1 = "SELECT `userId` FROM `appointment` WHERE `docID` = '$docId' AND `date` = '$bookdate'";
				$result1 = mysqli_query($conn,$query1);
				$row1 = mysqli_fetch_array($result1,MYSQLI_ASSOC);
				$userIds=$row1['userId'];
				$abc=explode(",",$userIds);
				
				if(in_array($uId, $abc)){
					echo("<script>alert('You alredy have an appointment for this day with this doctor');
							window.location.href = 'http://localhost/hk/bookdoc.php';
						</script>");
				}
				else{
					 	$userIds=$userIds.",".$uId;
				    $query = "UPDATE `appointment` SET `userId`='$userIds' WHERE `docID` = '$docId' AND `date` = '$bookdate'";
					mysqli_query($conn,$query);
					echo("<script>alert('Your Appointment Is Booked')
							window.location.href = 'http://localhost/hk/bookdoc.php';
						</script>");
				}
?>