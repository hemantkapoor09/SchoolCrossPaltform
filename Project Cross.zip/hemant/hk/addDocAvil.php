<?php 
include("conn.php");
 if(isset($_POST["setAvil"]))
    {
        $av = $_POST["avilable"];
        $cou = count($av);
        $docId = $_SESSION["docId"];
        for($i=0;$i<$cou;$i++)
        {
        	$query = "INSERT INTO `appointment`(`date`, `docId`) VALUES ('$av[$i]','$docId')";
				$result = mysqli_query($conn,$query);
				mysqli_query($conn,$query);
        	header("Location: adminDoc.php");	
        }
    }
 ?>