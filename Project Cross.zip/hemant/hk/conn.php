<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$db = "bodyserivce";
$gapServer ="location: http://10.51.219.142:3000/";
// $gapServer ="location: http://192.168.2.10:3000/";

	$conn = new mysqli($servername, $username, $password, $db);
	session_start();
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

?>