<?php 

	include("conn.php");

    $query = "SELECT `docname`FROM `doctor` WHERE `id` = '".$_SESSION['docId']."'";
                $result = mysqli_query($conn,$query);
                $row = mysqli_fetch_array($result,MYSQLI_ASSOC);

                $query1 = "SELECT `date`, `userId` FROM `appointment` WHERE `docId` = '".$_SESSION['docId']."'";
                $result1 = mysqli_query($conn,$query1);
                $row1 = mysqli_fetch_array($result1,MYSQLI_ASSOC);

 ?>
 <!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no, width=device-width">
        <title>Blank App</title>
    </head>
    <body>
        <script type="text/javascript" src="cordova.js"></script>

   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
   <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
   <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        <style>
        .tabelContainer{
        	float:right;
        }
        .welcome{
        	/*background-color:#aca2a5;*/
        	margin-left:10%;
        	float:left;
        }
        	.table{
        	border:5px solid #444;
        		width:auto;
        	}
        	#upadte-sechdule{
        		margin-left:30%;
        	}
        	.brand{
			color:#222;
			text-shadow:2px 1px #3EBFEC
		}
        .app{
            float:left;
            margin-left:15%;
        }
        .tabls{
            padding-top:5%;
            margin-bottom:10%;
            clear:both;
            float: left;
            width:100%;
            background-color: #eee;
        }
        .table{
            border:5px solid #444;
                width:auto;
            }
    	</style>
<script>
	var currentdate = new Date(); 
	var dat= "Last Sync: " + currentdate.getDate() + "/" + (currentdate.getMonth()+1)  + "/" + currentdate.getFullYear();
	var time = currentdate.getHours() + ":"+ currentdate.getMinutes();
     
                // alert(dat+time);
	// var firstDay = new Date();
	// var nextWeek = new Date(firstDay.getTime() + 7 * 24 * 60 * 60 * 1000);

</script>
<br>
		<div class="brand  text-center">
			<i class="fas fa-h-square fa-6x" style=""><span style="font-size:55px;font-family: serif;">ealth Care </span></i>
			&nbsp;&nbsp;
			<i class="fas fa-hands fa-3x pull-right" style="text-shadow:2px 2px #3EBFEC"></i><hr class="h"><br><br>
		</div>
<div class="container-fluid">
			<h1 class="text-center" style="color:#3EBFEC;">Welcome To Doctor's DashBoard</h1><br>
		<div class="welcome">
			<i class="fas fa-user-md fa-6x" style="text-shadow:2px 2px #3EBFEC;"></i>
			<h3>Hi,&nbsp;<?php echo($row['docname']); ?></h3>
		</div>
        <div class="tabls">
        <div class="app">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Your Appointments with Patients &nbsp;&nbsp;<i class="far fa-calendar-check fa-2x" style="text-shadow:2px 2px #3EBFEC;"></i></th>
                    </tr>
                </thead>
                <tbody>
           <?php 

             while( $row1 = mysqli_fetch_array($result1) )
            {
                $userIds = $row1['userId'];
                $q=explode(',', $userIds);
                $count = count($q);
                $date = $row1['date'];
                echo("
                        <tr>
                            <td>
                                On&nbsp;&nbsp;".$date."&nbsp;&nbsp;With&nbsp;".$count."&nbsp;patients                           
                            </td>
                        </tr>
                    ");
            }
            ?>
            </tbody>
            </table>
        </div>
    	<div class="tabelContainer">
            <form class="form_text" action = "addDocAvil.php" method = "POST">
    		<table class="table table-striped">
    			<thead>
    				<tr>
    					<th>Set your Avilablity for next Week&nbsp;&nbsp;<i class="far fa-calendar-check fa-2x" style="text-shadow:2px 2px #3EBFEC;"></i></th>
    				</tr>
    			</thead>
    			<tbody>
    				<?php
    					for($i=0;$i<7;$i++)
    					{
    						$d=strtotime("+".$i." day"); 
    						$dayT = date("l",$d);
    						$dateT = date("Y/m/d",$d);
    						echo ("
				    				 <tr>
				    					<td>
    										<input type='checkbox' name='avilable[]'' id='dateAvl' value='".$dateT."'>&nbsp;&nbsp;".
		    								$dayT."&nbsp;&nbsp;". $dateT."
				    					</td>																		
				    				</tr>"
		    					);
    					}
    				 ?>
    			</tbody>
    		</table>
    		<button class="btn btn-info" id="upadte-sechdule" name="setAvil"><i class="far fa-check-circle"></i>&nbsp;Update Sechdule</button>

<br><br><br>
    	</div>
        </div>

</div>
    </body>
    </html>