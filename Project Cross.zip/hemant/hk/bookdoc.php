<?php 
		include("conn.php");
	    $query = "SELECT * FROM doctor";
		$result = mysqli_query($conn,$query);
		
 ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no, width=device-width">
        <title>Blank App</title>
    </head>
    <body>
        <script type="text/javascript" src="cordova.js"></script>

   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
   <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
   <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        <style>
		body{
		}
		.panel{
			margin-left:auto;
			margin-right:auto;
			width:100%;
			/*background-color:#eee;*/
			border:0.5px solid #bbb;
			/*box-shadow:2px 1px #777;*/

		}
	
		.login_text{
			color: #765;
			background: #2e6da4;
			padding: 2%;
			color: #fff;
		}
	</style>
	<div class="container text-center">

		<br>
		<div class="brand">
			<i class="fas fa-h-square fa-6x" style=""><span style="font-size:55px;font-family: serif;">ealth Care </span></i>
			&nbsp;&nbsp;
			<i class="fas fa-hands fa-3x pull-right" style="text-shadow:2px 2px #3EBFEC"></i><hr class="h"><br><br><br><br>
		</div>	
		<div class="row">
			&nbsp;&nbsp;&nbsp;

			<div class="panel panel-primary">
				<div class="panel-heading">
					<h2 class="login_text">
						<i class="far fa-calendar-plus fa-2x"></i>&nbsp;&nbsp;Book Appointment
					</h2>
				</div>
				<div class="panel-body">
					  <table class="table table-striped">
					  		<thead>
							    <tr>
									<th scope="col">Name</th>
									<th scope="col">Contact</th>
									<th scope="col">Address</th>
									<th scope="col">Specialization In</th>
									<th scope="col"></th>
							    </tr>
							</thead>
							<tbody>

							    <?php  
							    	while($row = mysqli_fetch_array( $result ))
									{
										echo("<form class='form_text' action='addApp.php' id='myform' method='POST'>");
								    	echo("<tr id='".$row['id']."'>");
								    		echo("<td> ".$row['docname']."</td>");
								    		echo("<td>".$row['address']."</td>");
								    		echo("<td>".$row['phone']."</td>");
								    		echo("<td><i>".$row['spcin']."</i></td>");
											echo("<td><input type='text' hidden='true' name='doctorId' id='doctorId' value='".$row['id']."'/></td>");
											echo("<td>	<button  id='".
								    			$row['id'].
								    			"' class='btn btn-info' onclick='myfun(this.id)'>Book</button>".
								    			"</td>");
										echo("</tr> </form>");
					
									}
								?>
							</tbody>
						</table>

				</div>
				    <div class="panel-footer ">
				    	<div class="pull-right">
				    		<i><b>&copy;&nbsp;K</b>apoor'z</i>
				    	<!-- <h6 class="pull-right"><p>Create an account  <a href="registration.html">Registered Now</a></p></h6> -->
				    	</div>
				    </div>
			</div>


		</div>
	</div>
<br><br><br>

  


<script>
	function myfun(id)
	{
		document.getElementById("myform").submit();
	}

	$(function(){
    	$('.btn-info').click(function()
    	{
	        var getIdFromRow = $(event.target).closest('tr').attr('id');
	        var getnameFromRow = $(event.target).closest('td').prev('td').prev('td').prev('td').prev('td').html();
	        // $('#docname').html(getnameFromRow);
	        // $('#docId').html(getIdFromRow);
	    });
	       // document.getElementById('doctorId').value= document.getElementById();
	});
</script>

    </body>
</html>
