<?php
 include("conn.php");
?>

	<div class="container">
	<div class="row">
		<?php
			if(isset($_POST["submitL"])){
				$email = $_POST["email"];
				$password = $_POST["password"];
								
				$query = "SELECT * FROM `users` WHERE `email` = '$email' AND `password` = '$password'";
				$result = mysqli_query($conn,$query);
				$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
				$count = mysqli_num_rows($result);
				  

				$query1 = "SELECT * FROM `doctor` WHERE `email` = '$email' AND `password` = '$password'";
				$result1 = mysqli_query($conn,$query1);
				$row1 = mysqli_fetch_array($result1,MYSQLI_ASSOC);
				$count1 = mysqli_num_rows($result1);
				  
				if($count == 1){
					$_SESSION['userId'] = $row["id"];
						header("".$gapServer."home.html");
				}
				else if($count1 == 1){
				$_SESSION['docId'] = $row1["id"];
						header("Location: adminDoc.php");	
					echo("hi doc".$row1["docname"]);
				}
				else {
					echo "Your Login Name or Password is invalid";
				}
				
			}
		?>
	</div>
</div>