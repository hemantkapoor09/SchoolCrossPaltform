<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no, width=device-width">
        <title>Blank App</title>
    </head>
    <body>

   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
   <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
        <style>
         .tabelContainer{
        	float:right;
        }
        .welcome{
        	/*background-color:#aca2a5;*/
        	margin-left:10%;
        	float:left;
        }
        	.table{
        	border:5px solid #444;
        		/*width:auto;*/
        	}
        	#upadte-sechdule{
        		margin-left:30%;
        	}
        	.brand{
			color:#222;
			text-shadow:2px 1px 
    	</style>
    	<div class="container text-center">

		<br>
			<div class="brand">
				<i class="fas fa-h-square fa-6x" style=""><span style="font-size:55px;font-family: serif;">ealth Care </span></i>
				&nbsp;&nbsp;
					<i class="fas fa-hands fa-3x pull-right" style="text-shadow:2px 2px #3EBFEC"></i><hr class="h"><br><br><br><br>
			</div>	
			
			<div class="row">
    		<table class="table table-striped">
    			<thead>
    				<tr>
    					<th>Your Appointments &nbsp;&nbsp;<i class="far fa-calendar-check fa-2x" style="text-shadow:2px 2px #3EBFEC;"></i></th>
    				</tr>
    			</thead>
    			<tbody>
					<?php
					 include("conn.php");
						$query1 = "SELECT * FROM `appointment`";
						$result1 = mysqli_query($conn,$query1);
						$row1 = mysqli_fetch_array($result1,MYSQLI_ASSOC);
						
						while( $row = mysqli_fetch_array($result1) )
						{
							$abc=explode(",",$row['userId']);
							
							if(in_array($_SESSION['userId'], $abc))
							{
									$doc= $row['docId'];
									$query= "SELECT  `docname` FROM `doctor` WHERE `id` ='$doc'";
									$result = mysqli_query($conn,$query);
									$row2 = mysqli_fetch_array($result,MYSQLI_ASSOC);
									$docname=$row2['docname'];
									$date= $row['date'];
								echo ("
				    				 <tr>
				    					<td>
											On&nbsp;&nbsp;<b>".$date."</b>&nbsp;&nbsp;With <b>".$docname."
										</b></td>																		
				    				</tr>"
		    						);
							}
						}
						
							  
					?>
					</tbody>
    		</table>
			</div> <!-- row -->
		</div> <!-- container -->
	</body>
</html>
