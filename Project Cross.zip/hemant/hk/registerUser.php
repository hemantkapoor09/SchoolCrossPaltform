<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no, width=device-width">
            </head>
            <body>

<?php 
	include("conn.php");
?>
<div class="container">
	<div class="row">
		<?php
			if(isset($_POST["submitR"])){
				$fname = $_POST["fname"];
				$lname = $_POST["lname"];
				$gender = $_POST["gender"];
				$sin = $_POST["sin"];
				$age = $_POST["age"];
				$email = $_POST["email"];
				$password = $_POST["password"];
				$address = $_POST["address"];
				$confirm_password = $_POST["confirm-password"];

				if($password == $confirm_password){
					$query = "INSERT INTO `users` (`fname`,`lname`,`gender`,`sin`,`age`,`email`,`password`,`address`) VALUES ('$fname','$lname','$gender','$sin','$age','$email','$password','$address')";
					mysqli_query($conn,$query);
					echo "<script>
							alert('Registration Successful! Login to continue.');
						</script>";
				header("".$gapServer."");
				}else{
					echo "<script>
							alert('Both Passwords must be same!');
							</script>";
				}
			}
		?>
	</div>
</div>
            </body>
            </html>
